if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('./workbox.js').then(function(registration) {
        // Registration was successful
        console.log('Worker registration successful with scope: ', registration.scope);
      }, function(err) {
        // registration failed :(
        console.log('Worker registration failed: ', err);
      });
    });
  }

