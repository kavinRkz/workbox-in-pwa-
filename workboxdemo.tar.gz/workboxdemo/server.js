var express = require('express');
var app = express();
var bodyParser     =         require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use("/", express.static(__dirname));
app.get('/jquery-3.2.1.js',function(req,res){
    res.sendFile("js/jquery-3.2.1.js");
  });


app.get('/',function(req,res){
    res.sendFile('/home/otg/workspace/workbox/index.html');
})


app.listen(3001);
