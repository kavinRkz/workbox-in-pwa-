importScripts('https://storage.googleapis.com/workbox-cdn/releases/3.0.0-beta.2/workbox-sw.js');

importScripts('/js/workboxmin.js');





self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', () => self.clients.claim());


if (workbox) {
  console.log(`Yay! Workbox is loaded 🎉`);
} else {
  console.log(`Boo! Workbox didn't load 😬`);
}

const workboxSW = new self.WorkboxSW();

workbox.routing.registerRoute(
  /.*\.(?:png|jpg|jpeg|svg|gif)/g,
  new workbox.strategies.CacheFirst({
    cacheName: 'my-image-cache',
  })
);

workbox.routing.registerRoute(
  new RegExp('.*\.html'),
  workbox.strategies.networkFirst({cachname:'my-html',})
);

workbox.routing.registerRoute(
    new RegExp('.*\.js'),
    workbox.strategies.networkFirst()
  );
  
  workboxSW.precache([
  
    { url: '/index.html'},
    ,
    {
      url: "/manifest.json",
      
    }

]);

workbox.routing.registerRoute(
  new RegExp('/images/'),
  workbox.strategies.networkFirst({
    cacheName: 'image-cache',
    plugins: [
      new workbox.expiration.Plugin({
        maxEntries: 20,
      }),
    ],
  })
);


workbox.googleAnalytics.initialize();


self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.open('workbox-runtime').then(function(cache) {
      return cache.match(event.request).then(function(response) {
        var fetchPromise = fetch(event.request).then(function(networkResponse) {
          cache.put(event.request, networkResponse.ofclone());
          return networkResponse;
        })
        return response || fetchPromise;
      })
    })
  );
});

